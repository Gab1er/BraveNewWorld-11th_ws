# Full Screen Page Preloading Effect
A simple and clean page preloader full screen effect for website page.

<a href="http://www.codiblog.com/2016/02/create-full-screen-preloading-effect.html">View Tutorial on Codiblog</a>
